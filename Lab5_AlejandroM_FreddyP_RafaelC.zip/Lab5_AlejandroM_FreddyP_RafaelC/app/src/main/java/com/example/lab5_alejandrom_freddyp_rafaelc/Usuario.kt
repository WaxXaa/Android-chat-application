package com.example.lab5_alejandrom_freddyp_rafaelc
data class Usuario(
    val nombre: String,
    val contra: String,
    val cedula: String,
    val correo: String,
    val tipo: Int
)
