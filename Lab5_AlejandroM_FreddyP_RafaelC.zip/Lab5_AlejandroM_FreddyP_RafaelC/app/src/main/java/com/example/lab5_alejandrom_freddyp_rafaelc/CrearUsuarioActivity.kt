package com.example.lab5_alejandrom_freddyp_rafaelc

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.ComponentActivity

class CrearUsuarioActivity: ComponentActivity() {
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var nombre: EditText
    private lateinit var contra: EditText
    private lateinit var cedula: EditText
    private lateinit var correo: EditText
    private lateinit var crearBtn: Button
    private lateinit var spn: Spinner

    private val mapa_opcciones = mapOf("1 Administrador" to 1,"2 Usuario Normal" to 2, "3 Registrador" to 3)
    private val lista_opciones:List<String> = listOf("1 Administrador", "2 Usuario Normal", "3 Registrador")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crear_usuario)
        sharedPreferences = getSharedPreferences("UsuariosPrefs", Context.MODE_PRIVATE)
        nombre = findViewById(R.id.nombre)
        contra = findViewById(R.id.contra)
        cedula = findViewById(R.id.ced)
        correo = findViewById(R.id.email)
        crearBtn = findViewById(R.id.crearUser)
        spn = findViewById(R.id.opciones_spinner)
        val adapterList = ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, lista_opciones)
        adapterList.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spn.adapter = adapterList
        crearBtn.setOnClickListener {
            when {
                nombre.text.toString().isEmpty() -> {
                    nombre.error = "nombre es obligatorio"
                }
                contra.text.toString().isEmpty() -> {
                contra.error = "contraseña es obligatoria"
                }
                cedula.text.toString().isEmpty() -> {
                    cedula.error = "cedula es obligatoria"
                }
                correo.text.toString().isEmpty() -> {
                    correo.error = "correo es obligatorio"
                }
                else -> {
                    val tipo: Int = mapa_opcciones[spn.selectedItem.toString()]!!
                    val usuario = Usuario(nombre.text.toString(), contra.text.toString(), cedula.text.toString(), correo.text.toString(), tipo)
                    guardarUsuario(usuario)
                    Toast.makeText(this, "se creo el usuario", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, BienvenidaActivity::class.java)
                    startActivity(intent)
                }
                }
            }


    }
    fun guardarUsuario(usuario: Usuario) {
        var usuarios = obtenerUsuarios().toMutableList()
        usuarios.add(usuario)
        val usuariosString = usuarios.joinToString("|") { "${it.nombre};${it.contra};${it.cedula};${it.correo};${it.tipo}" }
        val editor = sharedPreferences.edit()
        editor.putString("usuarios", usuariosString)
        editor.apply()
    }

    fun obtenerUsuarios(): List<Usuario> {
        val usuariosString = sharedPreferences.getString("usuarios", null) ?: return emptyList()
        return usuariosString.split("|").map {
            val campos = it.split(";")
            Usuario(campos[0], campos[1], campos[2], campos[3], campos[4].toInt())
        }
    }

}