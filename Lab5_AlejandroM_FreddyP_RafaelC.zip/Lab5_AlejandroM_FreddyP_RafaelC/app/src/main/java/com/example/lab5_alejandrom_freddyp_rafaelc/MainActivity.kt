package com.example.lab5_alejandrom_freddyp_rafaelc

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.ComponentActivity
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader

class MainActivity : ComponentActivity() {
    private var exist = false
    private lateinit var ingresar: Button
    private lateinit var correo: EditText
    private lateinit var contra: EditText
    private lateinit var spn_tipo: Spinner
    private var lista_tipos = listOf("Usuario Especial", "Otro")
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        ingresar = findViewById(R.id.ingresar)
        correo = findViewById(R.id.correo)
        contra = findViewById(R.id.contrasena)
        spn_tipo = findViewById(R.id.spn_tipoU)
        val adapterList = ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, lista_tipos)
        adapterList.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spn_tipo.adapter = adapterList

        ingresar.setOnClickListener {
            if(correo.text.toString().isEmpty()) {
                correo.error = "correo obligatorio"
            } else if (contra.text.toString().isEmpty()) {
                contra.error = "contraseña obligatoria"
            }
            else {
                if (correo.text.toString() == "ejemplo@email.com" && contra.text.toString() == "contra")  {
                    val intent = Intent(this,BienvenidaActivity::class.java)
                    startActivity(intent)
                }else {
                if(spn_tipo.selectedItem.toString() == "Usuario Especial"){
                try {

                    val br = BufferedReader(InputStreamReader(openFileInput("usuarios.txt")))
                    var line: String
                    // Inicializa el contador de líneas
                    while (br.readLine().also { line = it } != null) {
                        val datosUsuario =
                            line.split(";".toRegex()).dropLastWhile { it.isEmpty() }
                                .toTypedArray()
                        Toast.makeText(this, datosUsuario[0] + " " + datosUsuario[2], Toast.LENGTH_SHORT).show()
                        if(datosUsuario[1] == contra.text.toString() && datosUsuario[3] == correo.text.toString()) {

                            val bundle = Bundle()
                            bundle.putString("nombre", datosUsuario[0])
                            bundle.putString("contra", datosUsuario[1])
                            bundle.putString("cedula", datosUsuario[2])
                            bundle.putString("correo", datosUsuario[3])
                            bundle.putInt("tipo", datosUsuario[4].toInt())
                            val intent = Intent(this,BienvenidaActivity::class.java)
                            intent.putExtras(bundle)
                            startActivity(intent)
                        }

                    }
                    correo.text.clear()
                    contra.text.clear()
                    Toast.makeText(this, "Archivo-El Usuario no Existe\nVuelva a introducir los datos", Toast.LENGTH_SHORT).show()

                    br.close() // Importante cerrar el BufferedReader después de leer

                    // Ahora puedes usar fileContent como necesites
                } catch (e: IOException) {
                    e.printStackTrace()
                }
                } else {

                    val pref = getSharedPreferences("UsuariosPrefs", Context.MODE_PRIVATE)
                    val usuariosString = pref.getString("usuarios", null)
                    usuariosString?.split("|")?.map {
                        val datosUsuario = it.split(";")
                        if (datosUsuario[1] == contra.text.toString() && datosUsuario[3] == correo.text.toString()) {
                            val bundle = Bundle()
                            bundle.putString("nombre", datosUsuario[0])
                            bundle.putString("contra", datosUsuario[1])
                            bundle.putString("cedula", datosUsuario[2])
                            bundle.putString("correo", datosUsuario[3])
                            bundle.putInt("tipo", datosUsuario[4].toInt())
                            val intent = Intent(this, BienvenidaActivity::class.java)
                            intent.putExtras(bundle)
                            startActivity(intent)

                        }

                    }
                    correo.text.clear()
                    contra.text.clear()
                    Toast.makeText(
                        this,
                        "Share-El Usuario no Existe\nVuelva a introducir los datos",
                        Toast.LENGTH_SHORT
                    ).show()
                }

                }

            }}



        }
    }


