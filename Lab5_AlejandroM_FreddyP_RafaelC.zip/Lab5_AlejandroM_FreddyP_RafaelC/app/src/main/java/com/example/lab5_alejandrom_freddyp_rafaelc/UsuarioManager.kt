package com.example.lab5_alejandrom_freddyp_rafaelc

import android.content.Context
import android.content.SharedPreferences

class UsuarioManager(context: Context) {
    private val sharedPreferences: SharedPreferences = context.getSharedPreferences("UsuariosPrefs", Context.MODE_PRIVATE)

    fun guardarUsuario(usuario: Usuario) {
        val usuarios = obtenerUsuarios().toMutableList()
        usuarios.add(usuario)
        val usuariosString = usuarios.joinToString("|") { "${it.nombre};${it.contra};${it.cedula};${it.correo};${it.tipo}" }
        val editor = sharedPreferences.edit()
        editor.putString("usuarios", usuariosString)
        editor.apply()
    }

    fun obtenerUsuarios(): List<Usuario> {
        val usuariosString = sharedPreferences.getString("usuarios", null) ?: return emptyList()
        return usuariosString.split("|").map {
            val campos = it.split(",")
            Usuario(campos[0], campos[1], campos[2], campos[3], campos[4].toInt())
        }
    }
}
