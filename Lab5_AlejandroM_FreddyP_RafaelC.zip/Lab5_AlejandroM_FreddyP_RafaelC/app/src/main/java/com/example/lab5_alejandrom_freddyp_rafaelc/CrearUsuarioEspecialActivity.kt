package com.example.lab5_alejandrom_freddyp_rafaelc

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity
import java.io.OutputStreamWriter

class CrearUsuarioEspecialActivity: ComponentActivity() {
    private lateinit var nombre: EditText
    private lateinit var contra: EditText
    private lateinit var cedula: EditText
    private lateinit var correo: EditText
    private lateinit var crearBtn: Button
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crear_usuario_especial)
        nombre = findViewById(R.id.nombre_es)
        contra = findViewById(R.id.contra_es)
        cedula = findViewById(R.id.ced_es)
        correo = findViewById(R.id.email_es)
        crearBtn = findViewById(R.id.crearUser_es)
        crearBtn.setOnClickListener {
            when {
                nombre.text.toString().isEmpty() -> {
                    nombre.error = "nombre es obligatorio"
                }
                contra.text.toString().isEmpty() -> {
                    contra.error = "contraseña es obligatoria"
                }
                cedula.text.toString().isEmpty() -> {
                    cedula.error = "cedula es obligatoria"
                }
                correo.text.toString().isEmpty() -> {
                    correo.error = "correo es obligatorio"
                }
                else -> {
                    try {
                        val nuevoUsuarioEspecial: String =
                                nombre.getText().toString()+
                                    ";;"+ contra.getText().toString() +
                                    ";;"+ cedula.getText().toString() +
                                    ";;"+ correo.getText().toString() +
                                        ";;4\n"
                        val osw = OutputStreamWriter(openFileOutput("usuarios.txt", MODE_APPEND))
                        osw.write(nuevoUsuarioEspecial)
                        osw.close()

                    } catch (ex: Exception) {
                        Log.e("Ficheros", "Error al crear un nuevo contacto en contacto.txt", ex)
                    }
                    Toast.makeText(this, "se creo el usuario", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, BienvenidaActivity::class.java)
                    startActivity(intent)
                }
            }
        }


    }
}